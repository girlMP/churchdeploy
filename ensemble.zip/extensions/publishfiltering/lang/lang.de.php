<?php

	$about = array(
		'name' => 'Deutsch',
		'author' => array(
			'name' => 'Nils Hörrmann',
			'email' => 'post@nilshoerrmann.de',
			'website' => 'http://www.nilshoerrmann.de'
		),
		'release-date' => '2011-03-17'
	);

	/**
	 * Publish Filtering
	 */
	$dictionary = array(

		'contains' => 
		'enthält',

		'entries' => 
		'Einträge',

		'entry' => 
		'Eintrag',

		'is' => 
		'entspricht',

		'Filter' => 
		'Filtern',

		'Clear filters' => 
		'Filter löschen',
		
		'Disable publish filtering for this section' =>
		'Suchfilter für diesen Bereich deaktivieren'

	);
