<?php

	$about = array(
		'name' => 'Deutsch',
		'author' => array(
			'name' => 'Nils Hörrmann',
			'email' => 'post@nilshoerrmann.de',
			'website' => ''
		),
		'release-date' => '2011-02-15'
	);

	/**
	 * Order Entries
	 */
	$dictionary = array(

		'Entry order saved.' => 
		'Sortierreihenfolge gespeichert.',

		'Entry Order' => 
		'Sortierreihenfolge',
		
		'%s Disable sorting of other columns when enabled' => 
		'%s Wenn dieses Feld aktiv ist, das Sortieren anderer Spalten verhindern',

		'%s Hide this field on publish page' => 
		'%s Diese Feld in der Einzelansicht verbergen',
		
		'drag to reorder' =>
		'zum Sortieren Einträge verschieben'
		
	);
