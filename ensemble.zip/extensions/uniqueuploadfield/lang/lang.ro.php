<?php

	$about = array(
		'name' => 'Română',
		'author' => array(
			'name' => 'Vlad Ghita',
			'email' => 'vlad_micutul@yahoo.com',
		),
		'release-date' => '2011-02-10'
	);

	/**
	 * Field: Unique File Upload
	 */
	$dictionary = array(
		
		'Unique File Upload' =>
		'Încărcare fişier unică',
	
	);
