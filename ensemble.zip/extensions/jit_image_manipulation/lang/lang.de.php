<?php

	$about = array(
		'name' => 'Deutsch',
		'author' => array(
			'name' => 'Nils Hörrmann',
			'email' => 'post@nilshoerrmann.de',
			'website' => 'http://www.nilshoerrmann.de'
		),
		'release-date' => '2010-02-06',
	);


	/**
	 * JIT Image Manipulation
	 */
	$dictionary = array(

		'JIT Image Manipulation' => 
		'Echtzeitbildbearbeitung',

		'Leave empty to disable external linking. Single rule per line. Add * at end for wild card matching.' => 
		'Lassen Sie dieses Feld frei, wenn Sie externe Verweise unterbinden wollen. Eine Regel pro Zeile. Verwenden Sie * als Maskenzeichen.',

		'Trusted Sites' => 
		'Vertrauenswürdige Seiten',

	);
